define({
  "_widgetLabel": "Controlador de Barra de Âncora",
  "_layout_default": "Layout predefinido",
  "_layout_layout1": "Layout 0",
  "more": "Mais widgets"
});