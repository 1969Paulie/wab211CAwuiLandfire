define({
  "_widgetLabel": "Forankringslinjekontroller",
  "_layout_default": "Standardoppsett",
  "_layout_layout1": "Oppsett 0",
  "more": "Flere widgeter"
});