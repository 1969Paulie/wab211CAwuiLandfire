define({
  "_widgetLabel": "Ovladač panelu ukotvení",
  "_layout_default": "Výchozí rozvržení",
  "_layout_layout1": "Rozvržení 0",
  "more": "Více widgetů"
});