define({
  "_themeLabel": "실행 패드 테마",
  "_layout_default": "기본 레이아웃",
  "_layout_right": "오른쪽 레이아웃"
});