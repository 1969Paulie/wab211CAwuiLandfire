define({
  "_themeLabel": "Startfelt-tema",
  "_layout_default": "Standardoppsett",
  "_layout_right": "Høyre-oppsett"
});